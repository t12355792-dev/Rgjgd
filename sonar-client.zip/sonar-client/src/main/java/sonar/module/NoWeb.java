package sonar.module;

public class NoWeb extends Module {
    public final Setting bypass = add(Setting.mode("Bypass", 0, "None", "SkyCave"));
    private int counter;

    public NoWeb() { super("No Web", "Movements", "Убирает замедление в паутине"); }

    /** Вызывается из миксина: true = отменить замедление. */
    public boolean shouldCancel() {
        if (!enabled) return false;
        if (bypass.mode().equals("SkyCave")) return (counter++ % 4) != 0;
        return true;
    }
}
